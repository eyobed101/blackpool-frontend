let teamsLogo = {
    
}